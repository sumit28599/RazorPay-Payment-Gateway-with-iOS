//
//  ViewController.swift
//  Razorpay Payment Gateway
//
//  Created by apple on 25/09/23.
//

import UIKit
import Razorpay

class ViewController: UIViewController, RazorpayPaymentCompletionProtocol {
    func onPaymentError(_ code: Int32, description str: String) {
        let alert = UIAlertController(title: "Alert", message: "Failure methods", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cancle", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        let alert = UIAlertController(title: "Alert", message: "Success methods", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    var razorpay: RazorpayCheckout!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        razorpay = RazorpayCheckout.initWithKey("rzp_test_ebhcqF400D61uE", andDelegate: self)
    }

    @IBAction func razorpayAction(_ sender: Any) {
        self.showPaymentForm()
    }
    internal func showPaymentForm(){
        let options: [String:Any] = [
                    "amount": "100", //This is in currency subunits. 100 = 100 paise= INR 1.
                    "currency": "INR",//We support more that 92 international currencies.
                    "description": "purchase description",
                    "order_id": "order_DBJOWzybf0sJbb",
                  //  "image": "https://url-to-image.jpg",
                    "name": "business or product name",
                    "prefill": [
                        "contact": "9797979797",
                        "email": "foo@bar.com"
                    ],
                    "theme": [
                        "color": "#F37254"
                    ]
                ]
        razorpay.open(options)
    }

}

